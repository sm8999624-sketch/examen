from flask import Flask, request, jsonify
from tensorflow.keras.models import load_model
import numpy as np
from PIL import Image

app = Flask(__name__)
model = load_model('modelo_mnist.h5')

@app.route('/predict', methods=['POST'])
def predict():
    file = request.files['file']
    img = Image.open(file).convert('L').resize((28,28))
    x = np.array(img).astype('float32')/255
    x = x.reshape(1,28,28,1)
    pred = int(model.predict(x).argmax())
    return jsonify({'prediccion': pred})

if __name__ == '__main__':
    app.run(debug=False)